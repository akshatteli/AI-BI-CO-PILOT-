@echo off
cd /d "%~dp0"
echo Starting InsightPilot backend and frontend...
start "InsightPilot Backend" powershell -NoExit -Command "Set-Location -LiteralPath '%~dp0backend'; python -m uvicorn main:app --reload"
timeout /t 2 /nobreak >nul
start "InsightPilot Frontend" powershell -NoExit -Command "Set-Location -LiteralPath '%~dp0frontend'; if (!(Test-Path node_modules)) { npm install }; npm run dev"
echo.
echo Backend:  http://127.0.0.1:8000/docs
echo Frontend: http://localhost:5173
echo Keep both opened terminal windows running.
