# AI Business Intelligence Co-Pilot — Product Build

A locally runnable full-stack project based on the supplied 43-page BCA project report. The report's core workflow is implemented: upload CSV/Excel data, clean data, inspect quality, calculate KPIs, visualize trends and categories, ask the statistics-based Co-Pilot, detect anomalies, generate a simple forecast baseline, and download CSV/HTML reports.

## Technology
- Frontend: React 18, Vite, Recharts, Lucide icons, responsive CSS
- Backend: Python, FastAPI, Uvicorn, pandas, NumPy, OpenPyXL, scikit-learn
- Currency display: Indian Rupees (₹)

## Run on Windows

### 1. Backend
Open PowerShell in this folder and run:

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m uvicorn main:app --reload
```

Backend health: http://127.0.0.1:8000/api/health  
Swagger API docs: http://127.0.0.1:8000/docs

If PowerShell blocks activation, skip the activation line and run `python -m pip install -r requirements.txt` using your existing Python environment.

### 2. Frontend
Open a **second** PowerShell terminal in the project root:

```powershell
cd frontend
npm install
npm run dev
```

Open the URL printed by Vite, normally http://localhost:5173.

## One-click helper files
- `start-backend.bat` opens the API server.
- `start-frontend.bat` installs packages if needed and starts Vite.

## Main features
1. CSV, XLSX and XLS upload with extension/size/read validation.
2. Dataset selector, searchable preview and data-quality profile (missing cells, duplicates, unique values, numeric summaries).
3. KPI detection for revenue/sales, expenses/costs, and profit where column names permit.
4. Revenue trend and category comparison charts when matching columns exist.
5. Basic data cleaning: remove duplicate rows, fill numeric nulls with medians and categorical nulls with modes.
6. Statistics-based natural-language Co-Pilot response. It does **not** call an external LLM by default; responses are transparent dataset summaries.
7. Isolation Forest anomaly flags (minimum 10 rows and one numeric column).
8. Seven-day linear-trend forecast baseline (requires at least five distinct valid dates and a numeric metric).
9. CSV export and downloadable HTML business report.
10. Basic API health and in-memory monitoring endpoint.

## Important limitations
- Dataset data is held in memory. Restarting the backend clears uploaded datasets; this build does not yet persist datasets to MongoDB.
- User registration/login and dataset ownership checks are included in the login-enabled build. Dataset storage remains in memory and is not durable across backend restarts. Do not expose this development server to the public internet or upload confidential customer/business data.
- The Co-Pilot is statistics/rule based and is not a connected large language model. Forecasts and anomaly flags are exploratory decision-support signals, not guarantees.
- The supplied report lists authentication and MongoDB as project requirements and describes predictive analytics/live integrations as future enhancements. For production use, add tested authentication/authorization, persistent storage, HTTPS, deployment configuration, and automated tests before handling sensitive data.

## Sample data
Use `sample-data.csv` to try the upload workflow. A copy of the supplied project report is included for reference.


## Login and user accounts
- Register with name, email, and a password of at least 8 characters.
- Passwords are stored as Argon2 hashes in the local SQLite `users.db` file.
- Login returns a signed 12-hour JWT; dataset API routes require a valid token and dataset ownership is checked.
- Install backend requirements after updating this version. Set a strong, stable `JWT_SECRET` in your environment before deployment.
- This is a local/student-project baseline, not a substitute for a security review before public production deployment. Dataset storage is currently in-memory and resets when the backend restarts.

## Login and registration

The app opens on the InsightPilot sign-in page. New users can choose **Register here** to create an account with a name, email address, and password (minimum 8 characters). Passwords are stored as Argon2 hashes in the backend SQLite `users.db` database. Successful sign-in returns a JWT access token; dataset API requests require that token, and datasets are filtered/checked against the authenticated user's ID.

### Run locally (Windows CMD / VS Code terminal)

Terminal 1 — backend:

```cmd
cd backend
python -m pip install -r requirements.txt
python -m uvicorn main:app --reload
```

Terminal 2 — frontend:

```cmd
cd frontend
npm install
npm run dev
```

Open the Vite URL shown in the terminal (normally `http://localhost:5173`). API docs are at `http://127.0.0.1:8000/docs`.

### Security and deployment notes

Set a long, random `JWT_SECRET` in the backend environment before deployment. This project currently keeps uploaded datasets in process memory, so they are lost when the backend restarts; use persistent per-user storage before production. The “Forgot password?” label is a visual placeholder and does not yet implement a password-reset flow. Use HTTPS and a production-grade database/storage setup before handling confidential business data.

## Value proposition and business model panels
The dashboard includes an illustrative value proposition chart and a proposed business model table. The chart scores are explanatory design values only; they are not derived from uploaded datasets, customer research, or measured performance. Business-model rows are possible monetization approaches, not current revenue or validated pricing.


## Additional analytics and report-aligned roadmap

### Anomaly detection
The dashboard includes Isolation Forest anomaly detection for datasets with at least 10 rows and at least one numeric column. It reports flagged versus normal records, percentage flagged, numeric columns used, anomaly scores, and review severity. Flagged rows are investigation signals only; they are not proof of fraud or incorrect data.

### Features described in the final project report
The current application scope includes secure user login, CSV/Excel upload, data cleaning, KPI dashboard, interactive charts, natural-language Co-Pilot questions, business insights, downloadable reports, and performance monitoring.

The dashboard also displays a clearly labelled roadmap for the report's proposed enhancements:
- Live database connections
- Advanced forecasting for sales, revenue and expenses (a basic seven-day linear baseline is currently available)
- Scheduled report delivery
- Accounting, e-commerce and CRM integrations
- Additional data formats
- Large-dataset performance optimization and caching
- Stronger security, including encryption, two-factor authentication and role-based access
- Multi-language interface and Co-Pilot
- More explainable AI answers

Roadmap items are labelled as planned or partially available. They are not represented as completed integrations.


## Local connection fix (important)
The frontend now uses Vite's `/api` development proxy to forward API calls to `http://127.0.0.1:8000`. This keeps browser requests same-origin and avoids common localhost/127.0.0.1 CORS mismatches. Keep the backend running while using the frontend.

### Easiest Windows startup
1. Install backend requirements once: open PowerShell in the project root and run `cd backend`, then `python -m pip install -r requirements.txt`.
2. Install frontend packages once: open another terminal in the project root and run `cd frontend`, then `npm install`.
3. Double-click `start-all.bat` from the project root. It opens separate backend and frontend terminals.
4. Open `http://localhost:5173`. Check `http://127.0.0.1:8000/api/health` if the dashboard reports a backend connection issue; it should return JSON with `"status": "ok"`.

If you previously had Vite running, stop it with Ctrl+C and restart it after extracting this updated ZIP so the new proxy configuration is loaded. If `/api/health` does not load, the backend is not running or failed during startup; read the backend terminal error and install requirements with `python -m pip install -r requirements.txt`.
