from fastapi import FastAPI, UploadFile, File, HTTPException, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import Optional
import pandas as pd
import numpy as np
import io, os, uuid
from datetime import datetime, timedelta
from pydantic import EmailStr
from pwdlib import PasswordHash
import jwt, sqlite3, secrets

app = FastAPI(title="AI Business Intelligence Co-Pilot API", version="1.0.0")
origin = os.getenv("ALLOWED_ORIGIN", "http://localhost:5173")
app.add_middleware(CORSMiddleware, allow_origins=[origin, "http://127.0.0.1:5173"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

DATASETS = {}
AUTH_DB = os.getenv("AUTH_DB", "users.db")
JWT_SECRET = os.getenv("JWT_SECRET", "CHANGE_THIS_SECRET_BEFORE_DEPLOYMENT_" + secrets.token_urlsafe(32))
JWT_ALGORITHM = "HS256"
password_hash = PasswordHash.recommended()

def init_auth_db():
    with sqlite3.connect(AUTH_DB) as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, created_at TEXT NOT NULL)")
init_auth_db()

def current_user(request: Request):
    header = request.headers.get("Authorization", "")
    if not header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Please log in to continue.")
    try:
        payload = jwt.decode(header[7:], JWT_SECRET, algorithms=[JWT_ALGORITHM])
        uid = payload.get("sub")
        if not uid: raise ValueError("Missing subject")
    except Exception:
        raise HTTPException(status_code=401, detail="Your session is invalid or expired. Please log in again.")
    with sqlite3.connect(AUTH_DB) as conn:
        row = conn.execute("SELECT id, name, email FROM users WHERE id = ?", (uid,)).fetchone()
    if not row: raise HTTPException(status_code=401, detail="Account not found. Please log in again.")
    return {"id": row[0], "name": row[1], "email": row[2]}

@app.post("/api/auth/register")
def register(payload: dict):
    name = str(payload.get("name", "")).strip()
    email = str(payload.get("email", "")).strip().lower()
    password = str(payload.get("password", ""))
    if not name or len(name) > 100: raise HTTPException(status_code=422, detail="Enter your name (up to 100 characters).")
    if "@" not in email or len(email) > 254: raise HTTPException(status_code=422, detail="Enter a valid email address.")
    if len(password) < 8: raise HTTPException(status_code=422, detail="Password must contain at least 8 characters.")
    uid = str(uuid.uuid4())
    try:
        with sqlite3.connect(AUTH_DB) as conn:
            conn.execute("INSERT INTO users (id, name, email, password_hash, created_at) VALUES (?, ?, ?, ?, ?)", (uid, name, email, password_hash.hash(password), datetime.utcnow().isoformat()))
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="An account with this email already exists.")
    token = jwt.encode({"sub": uid, "exp": datetime.utcnow() + timedelta(hours=12)}, JWT_SECRET, algorithm=JWT_ALGORITHM)
    return {"access_token": token, "token_type": "bearer", "user": {"id": uid, "name": name, "email": email}}

@app.post("/api/auth/login")
def login(payload: dict):
    email = str(payload.get("email", "")).strip().lower()
    password = str(payload.get("password", ""))
    if not email or not password: raise HTTPException(status_code=422, detail="Email and password are required.")
    with sqlite3.connect(AUTH_DB) as conn:
        row = conn.execute("SELECT id, name, email, password_hash FROM users WHERE email = ?", (email,)).fetchone()
    if not row or not password_hash.verify(password, row[3]): raise HTTPException(status_code=401, detail="Incorrect email or password.")
    token = jwt.encode({"sub": row[0], "exp": datetime.utcnow() + timedelta(hours=12)}, JWT_SECRET, algorithm=JWT_ALGORITHM)
    return {"access_token": token, "token_type": "bearer", "user": {"id": row[0], "name": row[1], "email": row[2]}}

@app.get("/api/auth/me")
def auth_me(user: dict = Depends(current_user)):
    return user


@app.middleware("http")
async def protect_dataset_routes(request: Request, call_next):
    path = request.url.path
    if path.startswith("/api/datasets"):
        try:
            user = current_user(request)
            if request.method != "POST" or path != "/api/datasets":
                parts = path.strip("/").split("/")
                if len(parts) >= 3:
                    dataset_id = parts[2]
                    item = DATASETS.get(dataset_id)
                    if item is None or item.get("owner_id") != user["id"]:
                        return __import__("fastapi").responses.JSONResponse(status_code=404, content={"detail":"Dataset not found for this account."})
            request.state.user = user
        except HTTPException as exc:
            return __import__("fastapi").responses.JSONResponse(status_code=exc.status_code, content={"detail":exc.detail})
    return await call_next(request)

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "AI Business Intelligence Co-Pilot API"}

def json_safe(value):
    if pd.isna(value): return None
    if isinstance(value, (np.integer,)): return int(value)
    if isinstance(value, (np.floating,)): return None if not np.isfinite(value) else float(value)
    if isinstance(value, (pd.Timestamp, datetime)): return value.isoformat()
    return value

def serialize_df(df, limit=100):
    safe = df.head(limit).copy()
    safe = safe.replace({np.nan: None})
    return safe.to_dict(orient="records")

def get_dataset(dataset_id):
    if dataset_id not in DATASETS:
        raise HTTPException(status_code=404, detail="Dataset not found. Upload a dataset first.")
    return DATASETS[dataset_id]["df"]

@app.post("/api/datasets")
async def upload_dataset(request: Request, file: UploadFile = File(...)):
    name = (file.filename or "").lower()
    if not (name.endswith(".csv") or name.endswith(".xlsx") or name.endswith(".xls")):
        raise HTTPException(status_code=400, detail="Please upload a CSV or Excel file.")
    max_mb = int(os.getenv("MAX_UPLOAD_MB", "20"))
    raw = await file.read()
    if len(raw) > max_mb * 1024 * 1024:
        raise HTTPException(status_code=413, detail=f"File exceeds the {max_mb} MB upload limit.")
    try:
        df = pd.read_csv(io.BytesIO(raw)) if name.endswith(".csv") else pd.read_excel(io.BytesIO(raw))
    except Exception:
        raise HTTPException(status_code=400, detail="Could not read this file. Check that it is a valid CSV or Excel workbook.")
    if df.empty or len(df.columns) == 0:
        raise HTTPException(status_code=400, detail="The uploaded file has no usable rows or columns.")
    df.columns = [str(c).strip() or f"column_{i+1}" for i, c in enumerate(df.columns)]
    did = str(uuid.uuid4())
    DATASETS[did] = {"name": file.filename, "df": df, "uploaded_at": datetime.utcnow().isoformat(), "owner_id": request.state.user["id"]}
    return {"id": did, "name": file.filename, "rows": int(df.shape[0]), "columns": int(df.shape[1]), "uploaded_at": DATASETS[did]["uploaded_at"]}

@app.get("/api/datasets")
def list_datasets(request: Request):
    uid = request.state.user["id"]
    return [{"id": k, "name": v["name"], "rows": int(v["df"].shape[0]), "columns": int(v["df"].shape[1]), "uploaded_at": v["uploaded_at"]} for k,v in DATASETS.items() if v.get("owner_id") == uid]

@app.get("/api/datasets/{dataset_id}/preview")
def preview(dataset_id: str, page: int = 1, page_size: int = 10, search: Optional[str] = None):
    df = get_dataset(dataset_id)
    page_size = max(1, min(page_size, 100))
    filtered = df
    if search:
        mask = df.astype(str).apply(lambda col: col.str.contains(search, case=False, na=False)).any(axis=1)
        filtered = df[mask]
    start = max(0, page-1) * page_size
    return {"columns": list(df.columns), "rows": serialize_df(filtered.iloc[start:start+page_size], page_size), "total": int(len(filtered)), "page": page, "page_size": page_size}

@app.get("/api/datasets/{dataset_id}/profile")
def profile(dataset_id: str):
    df = get_dataset(dataset_id)
    numeric = df.select_dtypes(include=np.number)
    columns = []
    for c in df.columns:
        s = df[c]
        item = {"name": str(c), "dtype": str(s.dtype), "missing": int(s.isna().sum()), "missing_pct": round(float(s.isna().mean()*100), 2), "unique": int(s.nunique(dropna=True))}
        if pd.api.types.is_numeric_dtype(s):
            vals = s.dropna()
            item["stats"] = {"min": json_safe(vals.min()) if len(vals) else None, "max": json_safe(vals.max()) if len(vals) else None, "mean": json_safe(vals.mean()) if len(vals) else None, "median": json_safe(vals.median()) if len(vals) else None, "std": json_safe(vals.std()) if len(vals) > 1 else None}
        columns.append(item)
    return {"rows": int(len(df)), "column_count": int(len(df.columns)), "duplicate_rows": int(df.duplicated().sum()), "columns": columns, "numeric_columns": list(numeric.columns)}

def find_column(df, words, numeric_only=False):
    for c in df.columns:
        if any(w in str(c).lower() for w in words) and (not numeric_only or pd.api.types.is_numeric_dtype(df[c])):
            return c
    return None

@app.get("/api/datasets/{dataset_id}/analytics")
def analytics(dataset_id: str):
    df = get_dataset(dataset_id)
    num = df.select_dtypes(include=np.number)
    revenue_col = find_column(df, ["revenue", "sales", "amount", "income", "value", "total"], True)
    expense_col = find_column(df, ["expense", "cost", "spend"], True)
    profit_col = find_column(df, ["profit", "margin"], True)
    revenue = float(df[revenue_col].sum()) if revenue_col else None
    expense = float(df[expense_col].sum()) if expense_col else None
    profit = float(df[profit_col].sum()) if profit_col else (revenue-expense if revenue is not None and expense is not None else None)
    category_col = find_column(df, ["category", "product", "segment", "department", "type"])
    date_col = find_column(df, ["date", "time", "day", "month"])
    trend = []
    if date_col and revenue_col:
        tmp = df[[date_col, revenue_col]].copy()
        tmp[date_col] = pd.to_datetime(tmp[date_col], errors="coerce")
        tmp = tmp.dropna().sort_values(date_col)
        if len(tmp):
            tmp["period"] = tmp[date_col].dt.strftime("%Y-%m-%d")
            trend = [{"date": str(k), "value": float(v)} for k,v in tmp.groupby("period")[revenue_col].sum().tail(30).items()]
    category = []
    if category_col and revenue_col:
        tmp = df.groupby(category_col, dropna=False)[revenue_col].sum().sort_values(ascending=False).head(8)
        category = [{"name": str(k) if pd.notna(k) else "Missing", "value": float(v)} for k,v in tmp.items()]
    recent = serialize_df(df.tail(8).iloc[::-1], 8)
    insights = []
    if revenue_col:
        insights.append({"title": f"{revenue_col} summary", "finding": f"Total across {len(df):,} rows is {revenue:,.2f}.", "basis": f"Calculated from the '{revenue_col}' column.", "action": "Compare periods and segments before making decisions."})
    missing = int(df.isna().sum().sum())
    if missing:
        insights.append({"title": "Data completeness", "finding": f"{missing:,} missing cells were found.", "basis": "Computed across all columns.", "action": "Review missing values before interpreting results."})
    return {"rows": int(len(df)), "columns": int(len(df.columns)), "revenue": revenue, "expenses": expense, "profit": profit, "transaction_count": int(len(df)), "revenue_column": str(revenue_col) if revenue_col else None, "expense_column": str(expense_col) if expense_col else None, "profit_column": str(profit_col) if profit_col else None, "trend": trend, "category": category, "recent": recent, "insights": insights, "date_column": str(date_col) if date_col else None, "category_column": str(category_col) if category_col else None}

@app.post("/api/datasets/{dataset_id}/anomalies")
def anomalies(dataset_id: str):
    df = get_dataset(dataset_id)
    numeric = df.select_dtypes(include=np.number).replace([np.inf, -np.inf], np.nan)
    if len(numeric.columns) < 1 or len(df) < 10:
        raise HTTPException(status_code=422, detail="Anomaly detection needs at least 10 rows and one numeric column.")
    numeric = numeric.fillna(numeric.median()).fillna(0)
    from sklearn.ensemble import IsolationForest
    model = IsolationForest(contamination="auto", random_state=42)
    flags = model.fit_predict(numeric)
    scores = model.decision_function(numeric)
    flagged_indices = np.where(flags == -1)[0]
    # Sort the most unusual records first (lowest decision-function score).
    idx = sorted(flagged_indices, key=lambda i: float(scores[i]))[:100]
    records = []
    for i in idx:
        row = {k: json_safe(v) for k,v in df.iloc[int(i)].to_dict().items()}
        row["_row"] = int(i+1)
        row["_anomaly_score"] = round(float(scores[i]), 5)
        row["_severity"] = "High" if scores[i] < -0.15 else "Review"
        records.append(row)
    flagged_count = int(len(flagged_indices))
    total_rows = int(len(df))
    return {
        "method": "Isolation Forest",
        "flagged_count": flagged_count,
        "normal_count": total_rows - flagged_count,
        "total_rows": total_rows,
        "flagged_percentage": round((flagged_count / total_rows) * 100, 2) if total_rows else 0,
        "numeric_columns": [str(c) for c in numeric.columns],
        "rows": records,
        "note": "Anomalies are statistical investigation signals, not proof of fraud or error. Review flagged records against source documents."
    }

@app.post("/api/datasets/{dataset_id}/forecast")
def forecast(dataset_id: str, date_column: str, target_column: str, horizon: int = 7):
    df = get_dataset(dataset_id)
    if date_column not in df.columns or target_column not in df.columns:
        raise HTTPException(status_code=400, detail="Choose valid date and target columns.")
    dates = pd.to_datetime(df[date_column], errors="coerce")
    vals = pd.to_numeric(df[target_column], errors="coerce")
    tmp = pd.DataFrame({"date": dates, "value": vals}).dropna().sort_values("date")
    if len(tmp) < 5:
        raise HTTPException(status_code=422, detail="Forecasting needs at least five valid date/value observations.")
    daily = tmp.groupby(tmp["date"].dt.floor("D"))["value"].mean().reset_index()
    if len(daily) < 5:
        raise HTTPException(status_code=422, detail="Forecasting needs at least five distinct dates.")
    x = np.arange(len(daily))
    slope, intercept = np.polyfit(x, daily["value"].to_numpy(), 1)
    horizon = max(1, min(int(horizon), 30))
    last = daily["date"].iloc[-1]
    future = [{"date": (last + pd.Timedelta(days=i)).strftime("%Y-%m-%d"), "value": round(float(intercept+slope*(len(daily)-1+i)), 2), "kind": "forecast"} for i in range(1, horizon+1)]
    history = [{"date": d.strftime("%Y-%m-%d"), "value": round(float(v), 2), "kind": "actual"} for d,v in zip(daily["date"].tail(30), daily["value"].tail(30))]
    return {"history": history, "forecast": future, "method": "Linear trend baseline", "note": "A simple baseline estimate; not a guarantee. Validate against holdout data before business use."}

@app.post("/api/datasets/{dataset_id}/clean")
def clean_dataset(dataset_id: str):
    """Apply transparent basic cleaning: remove duplicate rows and fill missing values."""
    df = get_dataset(dataset_id).copy()
    before_rows = len(df)
    before_missing = int(df.isna().sum().sum())
    before_duplicates = int(df.duplicated().sum())
    df = df.drop_duplicates().copy()
    filled_cells = 0
    for column in df.columns:
        missing_count = int(df[column].isna().sum())
        if not missing_count:
            continue
        if pd.api.types.is_numeric_dtype(df[column]):
            fill_value = df[column].median()
            if pd.isna(fill_value):
                continue
        else:
            mode = df[column].mode(dropna=True)
            if mode.empty:
                continue
            fill_value = mode.iloc[0]
        df[column] = df[column].fillna(fill_value)
        filled_cells += missing_count
    DATASETS[dataset_id]["df"] = df
    return {
        "dataset_id": dataset_id,
        "rows_before": int(before_rows),
        "rows_after": int(len(df)),
        "removed_duplicates": int(before_duplicates),
        "missing_cells_before": before_missing,
        "filled_cells": int(filled_cells),
        "missing_cells_after": int(df.isna().sum().sum()),
        "note": "Numeric missing values use the column median; categorical missing values use the mode. Review assumptions before business use."
    }


@app.get("/api/datasets/{dataset_id}/export")
def export(dataset_id: str):
    df = get_dataset(dataset_id)
    buffer = io.StringIO()
    df.to_csv(buffer, index=False)
    buffer.seek(0)
    return StreamingResponse(iter([buffer.getvalue()]), media_type="text/csv", headers={"Content-Disposition": 'attachment; filename="dataset-export.csv"'})

class ChatRequest(BaseModel):
    message: str

@app.post("/api/datasets/{dataset_id}/copilot")
def copilot(dataset_id: str, request: ChatRequest):
    df = get_dataset(dataset_id)
    stats = {"rows": len(df), "columns": len(df.columns), "missing_cells": int(df.isna().sum().sum()), "duplicate_rows": int(df.duplicated().sum()), "numeric_columns": list(df.select_dtypes(include=np.number).columns)}
    return {"mode": "insights-only", "answer": "I can summarize verified dataset facts, but a live LLM provider is not configured. " + f"This dataset has {stats['rows']:,} rows, {stats['columns']} columns, {stats['missing_cells']:,} missing cells, and {stats['duplicate_rows']:,} duplicate rows. Numeric columns: {', '.join(map(str, stats['numeric_columns'])) or 'none detected'}. Treat this as a data summary, not an AI-generated causal explanation.", "stats": stats}

@app.get("/api/monitoring")
def monitoring():
    """Basic operational metrics for the local development workspace."""
    total_rows = sum(int(item["df"].shape[0]) for item in DATASETS.values())
    total_columns = sum(int(item["df"].shape[1]) for item in DATASETS.values())
    return {
        "status": "ok",
        "service": "AI Business Intelligence Co-Pilot API",
        "datasets_in_memory": len(DATASETS),
        "rows_in_memory": total_rows,
        "columns_in_memory": total_columns,
        "storage": "in-memory (datasets are cleared when the API restarts)",
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }

@app.get("/api/datasets/{dataset_id}/report")
def generate_report(dataset_id: str):
    """Download a self-contained HTML report based on computed dataset metrics."""
    from html import escape
    df = get_dataset(dataset_id)
    revenue_col = find_column(df, ["revenue", "sales", "amount", "income", "value", "total"], True)
    expense_col = find_column(df, ["expense", "cost", "spend"], True)
    profit_col = find_column(df, ["profit", "margin"], True)
    revenue = float(df[revenue_col].sum()) if revenue_col else None
    expense = float(df[expense_col].sum()) if expense_col else None
    profit = float(df[profit_col].sum()) if profit_col else (revenue-expense if revenue is not None and expense is not None else None)
    missing = int(df.isna().sum().sum())
    duplicates = int(df.duplicated().sum())
    def fmt(value):
        return "Not detected" if value is None else "₹" + format(value, ",.2f")
    name = escape(DATASETS[dataset_id]["name"])
    numeric = df.select_dtypes(include=np.number)
    stats_rows = "".join(f"<tr><td>{escape(str(c))}</td><td>{fmt(float(df[c].sum()))}</td><td>{fmt(float(df[c].mean()))}</td></tr>" for c in numeric.columns)
    if not stats_rows:
        stats_rows = '<tr><td colspan="3">No numeric columns detected.</td></tr>'
    html = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Business Intelligence Report</title><style>body{{font:15px Arial,sans-serif;color:#202842;max-width:1000px;margin:40px auto;padding:0 20px;background:#f7f8fc}}h1{{margin-bottom:5px}}.muted{{color:#727c91}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin:24px 0}}.card,section{{background:#fff;border:1px solid #e5e8f1;border-radius:12px;padding:18px}}.value{{font-size:24px;font-weight:700;margin-top:10px}}table{{border-collapse:collapse;width:100%;background:#fff}}td,th{{text-align:left;padding:12px;border-bottom:1px solid #eceef4}}th{{background:#f0f2f9}}.note{{line-height:1.6}}</style></head><body><h1>AI Business Intelligence Co-Pilot</h1><p class="muted">Business performance report · Dataset: {name} · Generated {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}</p><div class="grid"><div class="card">Rows<div class="value">{len(df):,}</div></div><div class="card">Columns<div class="value">{len(df.columns):,}</div></div><div class="card">Revenue / sales<div class="value">{fmt(revenue)}</div></div><div class="card">Expenses<div class="value">{fmt(expense)}</div></div><div class="card">Net profit<div class="value">{fmt(profit)}</div></div><div class="card">Data quality<div class="value">{missing:,} missing</div><p>{duplicates:,} duplicate rows</p></div></div><section><h2>Numeric column summary</h2><table><thead><tr><th>Column</th><th>Total</th><th>Average</th></tr></thead><tbody>{stats_rows}</tbody></table></section><section style="margin-top:16px"><h2>Interpretation and limitations</h2><p class="note">Metrics are computed directly from the uploaded dataset. Revenue, expense and profit values are shown only when matching numeric columns can be detected. A missing metric means the expected column was not detected; it does not mean the business value is zero.</p><p class="note">Validate source data and column meanings before making business decisions. This report is a descriptive summary, not a guarantee of future performance.</p></section></body></html>'''
    return StreamingResponse(iter([html]), media_type="text/html; charset=utf-8", headers={"Content-Disposition": 'attachment; filename="business-intelligence-report.html"'})
